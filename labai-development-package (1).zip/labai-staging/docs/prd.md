# Requirements Document

## 1. Application Overview

**Application Name:** LabAI

**Description:** LabAI is a virtual AI-powered laboratory assistant for STEM education, designed as a fully client-side web application. It provides students with interactive lab simulations and real-time AI supervision with immediate explanations of scientific phenomena. The application targets students who lack access to physical lab equipment, offering one hundred core experiments across Biology, Chemistry, Physics, Mathematics, and Computer Science subjects with AI-guided learning.

---

## 2. Users and Usage Scenarios

**Target Users:**
- High school and college students studying STEM subjects
- Students without access to physical laboratory equipment
- Self-learners seeking interactive science education

**Core Usage Scenarios:**
- Students select a subject, choose an experiment, interact with virtual lab equipment, receive real-time AI explanations of scientific phenomena, and generate personalized lab reports
- Educators demonstrating lab procedures in classrooms without physical equipment
- Students accessing 3D Virtual Lab directly from home page for freeform chemistry experiments

---

## 3. Page Structure and Functionality

```
LabAI Application
├── Landing/Home Screen
├── Subject Selection Screen
├── Experiment Selection Screen
├── Lab Bench Screen
│   ├── Simulation Panel (Left)
│   └── Right Panel
│       ├── Dr. Lab Widget (Top)
│       ├── Progress Indicators (Middle)
│       └── Finish Experiment Button (Bottom)
├── Lab Report Screen
└── 3D Virtual Lab Screen
```

### 3.1 Landing/Home Screen

**Purpose:** Introduce LabAI and provide entry point to the application

**Visual Elements:**
- Hero section with optimized animated lab equipment illustrations (SVG/CSS): beakers, flasks, test tubes, molecular structures floating and rotating with GPU-accelerated transforms
- Background: warm off-white #FDFCF9 with subtle gradient, optimized for performance
- Logo: \"Lab\" in Sora bold 56px deep forest green #1B4332 + \"AI\" in golden amber #F59E0B
- Headline: \"Your AI lab supervisor. Available 24/7.\" in Sora 48px deep forest green
- Description paragraph: warm sage green #6B8E7F text explaining that millions of students lack access to real lab equipment, and LabAI provides fully interactive virtual labs with AI supervision
- Feature highlights section with four cards:
  - 100+ Experiments (icon: test tube)
  - AI Tutor (icon: robot)
  - Virtual Lab (icon: lab bench)
  - Quizzes (icon: clipboard)
- Stats bar: \"100 Experiments · 5 Subjects · AI-Powered · Free\" in Inter 14px warm sage green
- Subject cards with icons and hover effects:
  - Biology 🧬 (icon: DNA helix)
  - Chemistry ⚗️ (icon: flask)
  - Physics ⚡ (icon: atom)
  - Mathematics 📐 (icon: graph)
  - Computer Science 💻 (icon: code brackets)
- CTA button: \"Start Learning\" with deep forest green background, golden amber hover state, clean rounded corners
- \"3D Lab\" button: prominent button with golden amber background, deep forest green hover state, positioned near CTA button, labeled \"Try 3D Virtual Lab\"
- Premium science education SaaS feel with careful spacing, warm typography, polished layout

**Functionality:**
- Animated lab equipment illustrations use CSS keyframe animations with GPU-accelerated transforms (translate3d, rotate3d) for smooth 60fps performance
- Hero section uses will-change CSS property for optimized rendering
- Clicking \"Start Learning\" button navigates to Subject Selection Screen with Framer-motion fade-and-slide transition
- Clicking \"Try 3D Virtual Lab\" button navigates directly to 3D Virtual Lab Screen with Framer-motion fade-and-slide transition
- Subject cards have hover lift effect and navigate to Subject Selection Screen with selected subject pre-loaded

### 3.2 Subject Selection Screen

**Purpose:** Allow users to choose subject area before selecting specific experiment

**Visual Elements:**
- Background: warm cream #FAF8F3
- Heading: \"What are you studying today?\" in Sora 40px bold deep forest green centered
- Subtitle: \"Choose a subject to explore your experiment\" in Inter 16px warm sage green
- Five compact subject cards in responsive grid:
  - Biology 🧬 — clean white card, deep forest green border, golden amber \"30 Experiments Available\" badge, fully active, subtle shadow lift on hover
  - Chemistry ⚗️ — clean white card, deep forest green border, golden amber \"30 Experiments Available\" badge, fully active, subtle shadow lift on hover
  - Physics ⚡ — clean white card, deep forest green border, golden amber \"30 Experiments Available\" badge, fully active, subtle shadow lift on hover
  - Mathematics 📐 — clean white card, deep forest green border, golden amber \"30 Experiments Available\" badge, fully active, subtle shadow lift on hover
  - Computer Science 💻 — clean white card, deep forest green border, golden amber \"10 Experiments Available\" badge, fully active, subtle shadow lift on hover
- Cards have warm shadows, clean typography, premium spacing, compact grid style

**Functionality:**
- Clicking any subject card navigates to Experiment Selection Screen with selected subject loaded
- Framer-motion fade-and-slide transition between screens

### 3.3 Experiment Selection Screen

**Purpose:** Allow users to choose from available experiments within selected subject

**Visual Elements:**
- Background: warm cream #FAF8F3
- Breadcrumb back arrow button in deep forest green
- Subject name + emoji as page header in Sora 36px deep forest green
- Search/filter bar at top: text input with warm cream border, filter dropdown for difficulty level (All/Beginner/Intermediate/Advanced)
- Experiment cards per subject in scrollable vertical grid with visual categorization
- Each card: clean white background, warm shadow, deep forest green accent border on hover
- Card contents:
  - Large preview icon/illustration representing experiment
  - Experiment name in Sora 22px bold deep forest green
  - Difficulty badge pill with color coding: Beginner (warm sage green), Intermediate (golden amber), Advanced (deep forest green)
  - Two-sentence description in Inter 14px warm sage green
  - \"Start Experiment\" button in deep forest green with golden amber hover
- Card hover effect: subtle shadow lift and border glow
- Better visual hierarchy with warm cream/sage theme

**Biology Experiments (30):**
1. **Protein Synthesis Lab** (Advanced) — DNA transcription to mRNA, ribosome translation, amino acid chain animation forming polypeptide
2. **Genetics & Punnett Square** (Intermediate) — monohybrid and dihybrid crosses, offspring genotype/phenotype ratio visualization, allele combination animation
3. **Cellular Respiration** (Advanced) — glycolysis, Krebs cycle, electron transport chain stages, live ATP counter showing energy production
4. **Action Potential Simulation** (Advanced) — neuron membrane with Na+/K+ ion channels, voltage propagation animation along axon, depolarization/repolarization phases
5. **Immune Response Lab** (Advanced) — antigen-antibody interaction animation, B-cell activation sequence, antibody production and pathogen neutralization
6. **Osmosis and Diffusion** (Beginner) — potato slices in hypotonic/isotonic/hypertonic solutions, animated water molecule particles crossing membrane
7. **Enzyme Activity Lab** (Intermediate) — liver catalyst + H2O2, foam height responds to temperature and pH sliders
8. **Photosynthesis Rate Lab** (Intermediate) — light intensity/CO2/temperature sliders, animated O2 bubbles, live graph
9. **DNA Extraction Simulation** (Beginner) — strawberry cell lysis animation, detergent/salt/alcohol layers, DNA strands precipitating in 3-layer test tube
10. **Mitosis Simulation** (Advanced) — prophase/metaphase/anaphase/telophase phases with chromosome movement, spindle fibers, AI quizzes each phase
11. **Meiosis Simulation** (Advanced) — two-stage division process, crossing over animation, haploid gamete formation
12. **Enzyme Kinetics** (Advanced) — Michaelis-Menten curve, substrate concentration vs reaction rate, Km and Vmax visualization
13. **Membrane Transport** (Intermediate) — active transport, passive transport, facilitated diffusion animations with ATP usage
14. **Bacterial Growth Curve** (Intermediate) — lag/log/stationary/death phases, live population graph, environmental factor controls
15. **Photosynthesis Light/Dark Reactions** (Advanced) — light-dependent reactions in thylakoid, Calvin cycle in stroma, NADPH and ATP production
16. **Blood Typing Lab** (Beginner) — ABO and Rh antigen-antibody reactions, agglutination visualization
17. **Ecological Succession** (Intermediate) — primary and secondary succession stages, species diversity changes over time
18. **Transpiration Rate** (Intermediate) — stomata opening/closing, environmental factor controls, water loss measurement
19. **Muscle Contraction** (Advanced) — sarcomere structure, actin-myosin sliding filament mechanism, calcium ion role
20. **Nerve Synapse** (Advanced) — neurotransmitter release, receptor binding, synaptic cleft animation
21. **Cell Membrane Structure** (Beginner) — phospholipid bilayer, protein channels, fluid mosaic model visualization
22. **Homeostasis Regulation** (Intermediate) — negative feedback loops, temperature/glucose regulation examples
23. **Genetic Mutations** (Advanced) — point mutations, frameshift mutations, DNA sequence changes and protein effects
24. **Embryonic Development** (Advanced) — fertilization, cleavage, gastrulation, organogenesis stages
25. **Plant Tropisms** (Intermediate) — phototropism, gravitropism, auxin distribution animation
26. **Kidney Filtration** (Advanced) — nephron structure, glomerular filtration, tubular reabsorption, urine formation
27. **Hormone Signaling** (Advanced) — receptor binding, signal transduction pathways, cellular response
28. **Ecosystem Energy Flow** (Intermediate) — trophic levels, energy pyramid, 10% rule visualization
29. **Antibiotics Resistance** (Advanced) — bacterial mutation, selection pressure, resistance evolution
30. **Circadian Rhythms** (Intermediate) — biological clock, light-dark cycle effects, melatonin regulation

**Chemistry Experiments (30):**
1. **Le Chatelier's Principle** (Advanced) — equilibrium system with concentration/temperature/pressure controls, reaction shift animation showing forward/reverse direction changes
2. **Electrolysis of Water** (Intermediate) — control voltage slider, watch H2 and O2 bubble production at cathode/anode electrodes, volume ratio 2:1 visualization
3. **Organic Reactions Lab** (Advanced) — choose functional groups (alcohol, alkene, alkyl halide), watch addition/substitution/elimination reaction mechanisms with electron movement arrows
4. **Gas Laws Simulation** (Intermediate) — sealed syringe with pressure/volume/temperature controls, interactively verify Boyle's Law, Charles' Law, Gay-Lussac's Law with live graphs
5. **Nuclear Reactions & Half-Life** (Advanced) — radioactive decay animation, half-life graph showing exponential decay, α/β/γ radiation types with penetration visualization
6. **Acid-Base Titration** (Beginner) — HCl dripping into NaOH, 12-color pH transition, 7-segment pH display
7. **Flame Test Lab** (Intermediate) — metal salt solutions + Bunsen burner, sodium orange/copper green/lithium crimson/potassium violet flame colors, bloom glow animation, virtual spectrometer
8. **Electrochemical Voltaic Cell** (Advanced) — zinc-copper galvanic cell, animated electron flow, ion movement through salt bridge, live voltmeter
9. **Paper Chromatography** (Intermediate) — plant pigment on paper strip, solvent traveling up, separating chlorophylls/carotene/xanthophyll bands, live Rf calculations
10. **Exothermic vs Endothermic** (Beginner) — virtual calorimeter, live temperature-vs-time graph, energy diagram
11. **Redox Reactions** (Advanced) — oxidation-reduction electron transfer animation, oxidation state changes, half-reaction equations
12. **Solubility Curves** (Intermediate) — temperature vs solubility graph, saturated/unsaturated/supersaturated solution visualization
13. **Reaction Rates** (Intermediate) — concentration/temperature/catalyst effects on reaction speed, collision theory animation
14. **Molecular Polarity** (Advanced) — electronegativity differences, dipole moment vectors, polar vs nonpolar molecule examples
15. **Crystallization** (Intermediate) — supersaturated solution cooling, crystal lattice formation animation
16. **Distillation** (Advanced) — fractional distillation apparatus, boiling point separation, vapor-liquid equilibrium
17. **Spectroscopy** (Advanced) — absorption spectrum, wavelength vs absorbance graph, Beer-Lambert law
18. **Electroplating** (Intermediate) — metal ion deposition on cathode, anode dissolution, current control
19. **Polymerization** (Advanced) — monomer to polymer chain formation, addition vs condensation polymerization
20. **3D Virtual Lab** (Advanced) — freeform chemistry lab with draggable glassware, reagent mixing, reaction matrix with 20+ visual outcomes
21. **Ionic Bonding** (Beginner) — electron transfer animation, lattice structure formation, ionic compound properties
22. **Covalent Bonding** (Beginner) — electron sharing animation, molecular orbital formation, bond types
23. **Hybridization** (Advanced) — sp3/sp2/sp orbital mixing, molecular geometry prediction
24. **Thermochemistry** (Intermediate) — enthalpy changes, Hess's law, calorimetry calculations
25. **Chemical Equilibrium** (Advanced) — equilibrium constant calculation, reaction quotient, ICE table
26. **Buffers** (Intermediate) — buffer solution pH stability, Henderson-Hasselbalch equation
27. **Oxidation States** (Intermediate) — assigning oxidation numbers, redox reaction identification
28. **Colligative Properties** (Advanced) — boiling point elevation, freezing point depression, osmotic pressure
29. **Kinetic Molecular Theory** (Intermediate) — gas particle motion, temperature-kinetic energy relationship
30. **Electronegativity** (Beginner) — Pauling scale, bond polarity prediction, dipole moments

**Physics Experiments (30):**
1. **Simple Harmonic Motion (Pendulum)** (Advanced) — adjustable pendulum length and mass, animated oscillation with period/frequency calculations, energy transformation visualization
2. **Wave Interference & Superposition** (Advanced) — two wave sources with adjustable frequency/amplitude, animated interference patterns showing constructive/destructive interference, phase difference controls
3. **Projectile Motion Lab** (Intermediate) — launch angle and velocity controls, animated trajectory with velocity vectors, range/height/time calculations, parabolic path visualization
4. **Optics: Refraction & Snell's Law** (Intermediate) — light ray passing through media with different refractive indices, angle of incidence/refraction controls, Snell's Law verification with live calculations
5. **Electric Fields & Potential** (Advanced) — charge placement controls, animated field lines, equipotential surfaces, electric potential visualization with color gradient
6. **Magnetic Force on Current** (Intermediate) — current-carrying wire in magnetic field, adjustable current/field strength, animated force direction (Fleming's left-hand rule), force magnitude calculation
7. **Thermodynamics: Carnot Cycle** (Advanced) — four-stage cycle visualization (isothermal expansion, adiabatic expansion, isothermal compression, adiabatic compression), P-V diagram, efficiency calculations
8. **Quantum Tunneling Simulation** (Advanced) — particle wave function approaching potential barrier, tunneling probability visualization, barrier width/height controls, transmission coefficient calculation
9. **Gravitational Orbits (Kepler)** (Intermediate) — planetary orbit simulation with adjustable mass/velocity, elliptical orbit animation, Kepler's laws verification, orbital period calculation
10. **Doppler Effect** (Intermediate) — moving sound source with adjustable velocity, animated wavefronts showing compression/expansion, observed frequency calculation, stationary observer position control
11. **Photoelectric Effect** (Advanced) — photon energy vs electron ejection, work function visualization, Einstein's equation verification
12. **Lenz's Law** (Advanced) — moving magnet through coil, induced current direction, magnetic flux change animation
13. **Capacitor Charging/Discharging** (Intermediate) — RC circuit, exponential voltage curve, time constant calculation
14. **Resonance** (Intermediate) — driven oscillator, amplitude vs frequency graph, resonance peak visualization
15. **Torque and Rotational Motion** (Intermediate) — lever arm, force application, angular acceleration calculation
16. **Fluid Dynamics: Bernoulli** (Advanced) — fluid flow through varying pipe diameter, pressure/velocity relationship, Bernoulli equation verification
17. **Standing Waves** (Intermediate) — string fixed at both ends, harmonic frequency controls, node/antinode visualization
18. **Compton Scattering** (Advanced) — photon-electron collision, wavelength shift calculation, momentum conservation
19. **Lorentz Force** (Advanced) — charged particle in crossed electric and magnetic fields, helical path animation
20. **Blackbody Radiation** (Advanced) — temperature vs wavelength spectrum, Wien's displacement law, Stefan-Boltzmann law
21. **Newton's Laws** (Beginner) — force application, mass variation, acceleration visualization, F=ma demonstration
22. **Conservation of Momentum** (Intermediate) — collision simulation, elastic/inelastic collisions, momentum calculations
23. **Conservation of Energy** (Intermediate) — roller coaster simulation, kinetic/potential energy transformation
24. **Circular Motion** (Intermediate) — centripetal force, angular velocity, radius variation effects
25. **Hooke's Law** (Beginner) — spring extension, force-displacement graph, spring constant calculation
26. **Coulomb's Law** (Intermediate) — electrostatic force between charges, distance variation, force calculation
27. **Ohm's Law** (Beginner) — voltage-current-resistance relationship, circuit simulation, V=IR demonstration
28. **Lens Optics** (Intermediate) — convex/concave lenses, focal length, image formation, ray diagrams
29. **Diffraction** (Advanced) — single-slit diffraction, double-slit interference, wavelength effects
30. **Relativity Time Dilation** (Advanced) — moving clock simulation, Lorentz factor, twin paradox visualization

**Mathematics Experiments (30):**
1. **Limits & Continuity Visualizer** (Intermediate) — function input field, x-value slider approaching limit point, animated point tracing function curve, left/right limit values displayed, continuity check
2. **Derivative Tracer (Tangent Line)** (Intermediate) — function curve displayed, x-value slider, animated tangent line at point, slope calculation shown, derivative value displayed
3. **Integral Area Visualizer** (Intermediate) — function curve with shaded area under curve, adjustable integration bounds, animated Riemann sum rectangles, area calculation displayed
4. **Taylor Series Approximation** (Advanced) — function input, center point control, number of terms slider, animated polynomial approximation overlaying original function, error visualization
5. **Matrix Transformation Visualizer** (Intermediate) — 2x2 matrix input fields, unit square displayed, animated transformation showing rotation/scaling/shearing, determinant and eigenvalues shown
6. **Complex Number Argand Plane** (Advanced) — complex number input (a+bi), point plotted on Argand plane, modulus and argument displayed, operations (addition/multiplication) with animated result
7. **Fourier Series Builder** (Advanced) — target waveform selection, number of harmonics slider, animated sine/cosine wave summation, resulting approximation overlaying target
8. **Probability Distributions** (Intermediate) — distribution type selector (normal/binomial/Poisson), parameter controls, animated probability density/mass function curve, area under curve for probability ranges
9. **Vector Fields & Gradient** (Advanced) — scalar field input, animated vector field arrows showing gradient direction, contour lines for scalar values, magnitude color gradient
10. **Conic Sections Explorer** (Beginner) — conic type selector (circle/ellipse/parabola/hyperbola), parameter sliders (a, b, c), animated curve drawing, equation displayed, focus/directrix shown
11. **Parametric Curves** (Intermediate) — parametric equation input (x(t), y(t)), animated curve tracing, velocity vector display
12. **Differential Equations** (Advanced) — slope field visualization, solution curve tracing, initial condition controls
13. **3D Surface Plotter** (Advanced) — function input f(x,y), rotatable 3D surface mesh, contour lines projection
14. **Linear Programming** (Intermediate) — constraint input, feasible region shading, optimal solution vertex highlighting
15. **Eigenvalue Visualizer** (Advanced) — matrix input, eigenvector direction arrows, eigenvalue scaling visualization
16. **Laplace Transform** (Advanced) — time-domain function input, frequency-domain output graph, pole-zero plot
17. **Numerical Integration** (Intermediate) — function input, method selector (trapezoidal/Simpson's), error comparison
18. **Root Finding** (Intermediate) — function input, method selector (Newton-Raphson/bisection), iteration animation
19. **Markov Chains** (Advanced) — state transition matrix, steady-state probability calculation, state diagram
20. **Fractal Generator** (Advanced) — fractal type selector (Mandelbrot/Julia), zoom controls, iteration depth slider
21. **Sequences & Series** (Beginner) — arithmetic/geometric sequences, partial sum visualization, convergence tests
22. **Trigonometric Functions** (Beginner) — unit circle, sine/cosine/tangent graphs, angle-radian conversion
23. **Logarithms** (Beginner) — exponential-logarithm relationship, graph transformations, properties demonstration
24. **Polynomial Roots** (Intermediate) — polynomial graphing, root finding, factor theorem visualization
25. **Vectors** (Intermediate) — vector addition/subtraction, dot product, cross product, geometric interpretation
26. **Matrices** (Intermediate) — matrix operations, determinant calculation, inverse matrix, system solving
27. **Statistics** (Intermediate) — mean/median/mode, standard deviation, data distribution visualization
28. **Regression Analysis** (Advanced) — linear/polynomial regression, least squares method, R-squared value
29. **Combinatorics** (Intermediate) — permutations, combinations, binomial coefficients, Pascal's triangle
30. **Graph Theory** (Advanced) — graph representation, shortest path algorithms, spanning trees

**Computer Science Experiments (10):**
1. **Binary Search Visualizer** (Intermediate) — sorted array display, search target input, animated binary search steps with index pointers, comparison count, time complexity O(log n) demonstration
2. **Sorting Algorithms** (Intermediate) — algorithm selector (bubble sort, merge sort, quick sort), array input, animated sorting process with color-coded comparisons/swaps, time complexity comparison
3. **Stack & Queue Operations** (Beginner) — push/pop/enqueue/dequeue buttons, animated data structure visualization, LIFO/FIFO principles demonstration
4. **Binary Tree Traversal** (Advanced) — tree structure builder, traversal method selector (in-order, pre-order, post-order, level-order), animated node visiting sequence
5. **Graph Algorithms** (Advanced) — graph builder, algorithm selector (BFS, DFS, Dijkstra), animated traversal/pathfinding with node coloring, shortest path visualization
6. **Recursion Visualizer** (Intermediate) — recursive function selector (factorial, Fibonacci, Tower of Hanoi), animated call stack, base case highlighting
7. **Hash Table Operations** (Intermediate) — hash function visualization, collision handling (chaining/open addressing), insert/search/delete operations
8. **Dynamic Programming** (Advanced) — problem selector (knapsack, longest common subsequence), memoization table visualization, optimal substructure demonstration
9. **Big O Notation** (Beginner) — algorithm complexity comparison, input size slider, execution time graph for O(1), O(n), O(n^2), O(log n), O(n log n)
10. **Finite State Machine** (Advanced) — state diagram builder, input string processing, state transition animation, accept/reject visualization

**Functionality:**
- Back arrow returns to Subject Selection Screen
- Search bar filters experiments by name in real-time
- Filter dropdown filters experiments by difficulty level
- Clicking any experiment card navigates to Lab Bench Screen with selected experiment loaded
- Framer-motion fade-and-slide transition between screens

### 3.4 Lab Bench Screen

**Purpose:** Provide interactive simulation environment with real-time AI supervision

**Layout:**
- Split into two panels: 60% left (Simulation Panel), 40% right (Right Panel) on desktop
- Stacked vertically on mobile
- Background: warm cream #FAF8F3

#### 3.4.1 Simulation Panel (Left)

**Header Bar:**
- Display experiment name in Sora deep forest green
- \"Reset Experiment\" button in warm red outline style

**Canvas Area:**
- Clean white background with subtle warm grid lines
- All text labels, numbers, and annotations use dark text (deep forest green #1B4332 or black #000000) on light backgrounds for clear readability
- High contrast ensured throughout all canvas drawings
- Glassware with real glass effects: rgba transparency, liquid surface sine wave shimmer, gradient 3D depth, volume graduation markings
- 60fps requestAnimationFrame animations for droplets/bubbles
- Deep forest green and golden amber accent colors for interactive elements

**Biology Experiment Simulations:**

**Protein Synthesis Lab:**
- DNA double helix strand displayed
- \"Start Transcription\" button
- Animated mRNA formation from DNA template
- Ribosome moving along mRNA
- tRNA bringing amino acids
- Growing polypeptide chain animation
- Step indicator showing current phase
- 3D rotating molecule viewer showing amino acid structure

**Genetics & Punnett Square:**
- Parent genotype selectors (dropdown menus for alleles)
- Monohybrid cross option (one trait)
- Dihybrid cross option (two traits)
- Animated Punnett square grid filling with offspring genotypes
- Phenotype ratio visualization with color-coded results
- Percentage calculations displayed

**Cellular Respiration:**
- Glucose molecule input
- Three stage indicators: Glycolysis, Krebs Cycle, Electron Transport Chain
- \"Start Process\" button
- Animated molecule transformations through each stage
- Live ATP counter incrementing (2 ATP → 2 ATP → 34 ATP)
- NADH and FADH2 production visualization
- Final total ATP display
- 3D rotating molecule viewer showing glucose structure

**Action Potential Simulation:**
- Neuron axon displayed horizontally
- Resting potential indicator (-70mV)
- \"Stimulate\" button to trigger action potential
- Animated Na+ channels opening (depolarization wave)
- Voltage graph showing spike to +40mV
- Animated K+ channels opening (repolarization)
- Propagation wave traveling along axon
- Refractory period visualization

**Immune Response Lab:**
- Pathogen (antigen) entering system
- B-cell recognition animation
- \"Activate Immune Response\" button
- B-cell activation and proliferation
- Plasma cell differentiation
- Antibody production animation (Y-shaped molecules)
- Antibody-antigen binding visualization
- Pathogen neutralization sequence

**Osmosis and Diffusion:**
- Three beakers containing hypotonic, isotonic, hypertonic solutions
- Potato slice in each beaker
- Animated water molecule particles crossing cell membrane
- Visual changes in potato slice size over time
- 3D rotating molecule viewer showing water molecule structure

**Enzyme Activity Lab:**
- Test tube containing liver catalyst + H2O2
- Temperature slider control
- pH slider control
- Foam height animation responding to slider values
- Live reaction rate indicator

**Photosynthesis Rate Lab:**
- Cartoon plant rendered on canvas
- Three control sliders: light intensity, CO2 levels, temperature
- Animated oxygen bubbles floating up from leaves based on conditions
- Live graph showing photosynthesis rate over time
- 3D rotating molecule viewer showing CO2 and O2 structures

**DNA Extraction Simulation:**
- Strawberry cell lysis animation sequence
- Three-layer test tube showing detergent/salt/alcohol layers
- DNA strands precipitating animation
- Step-by-step process controls
- 3D rotating molecule viewer showing DNA double helix structure

**Mitosis Simulation:**
- Cell nucleus with chromosomes
- Phase progression controls: prophase/metaphase/anaphase/telophase
- Animated chromosome movement
- Spindle fiber visualization
- Phase indicator display

**Chemistry Experiment Simulations:**

**Le Chatelier's Principle:**
- Equilibrium reaction equation displayed (e.g., N2 + 3H2 ⇌ 2NH3)
- Three control sliders: concentration, temperature, pressure
- Animated molecules showing forward/reverse reaction rates
- Visual shift indicator (equilibrium shifts left/right)
- Color intensity changes representing concentration changes
- Live graph showing reaction quotient Q vs equilibrium constant K
- 3D rotating molecule viewer showing NH3 structure

**Electrolysis of Water:**
- Water container with two electrodes (cathode and anode)
- Voltage control slider (0-12V)
- \"Start Electrolysis\" button
- Animated H2 bubbles rising at cathode (left electrode)
- Animated O2 bubbles rising at anode (right electrode)
- Volume measurement tubes showing 2:1 ratio
- Live current indicator
- 3D rotating molecule viewer showing H2O, H2, O2 structures

**Organic Reactions Lab:**
- Reactant molecule builder (choose functional groups from dropdown)
- Reaction type selector: Addition, Substitution, Elimination
- Reagent selector (e.g., HBr, NaOH, H2SO4)
- \"Start Reaction\" button
- Animated electron movement arrows showing mechanism
- Bond breaking and forming animation
- Product molecule displayed with structural formula
- 3D rotating molecule viewer showing reactant and product structures

**Gas Laws Simulation:**
- Sealed syringe with movable piston
- Three control sliders: pressure, volume, temperature
- Law selector: Boyle's Law, Charles' Law, Gay-Lussac's Law
- Animated gas particles moving faster/slower based on temperature
- Piston moving in/out based on pressure/volume changes
- Live graph plotting selected law relationship
- Calculated values displayed (PV = nRT)

**Nuclear Reactions & Half-Life:**
- Radioactive isotope selector (e.g., Carbon-14, Uranium-238)
- Sample size input (number of atoms)
- \"Start Decay\" button
- Animated atoms decaying with particle emission
- Half-life timer counting down
- Exponential decay graph showing remaining atoms over time
- Radiation type visualization: α particles (helium nuclei), β particles (electrons), γ rays (photons)
- Penetration depth animation through paper/aluminum/lead

**Acid-Base Titration:**
- Large glass beaker containing NaOH solution
- Burette above beaker containing HCl acid solution
- Tap/valve control: click and hold to drip acid into beaker
- Animated red droplets falling from burette tip
- Liquid color changes through 12-color pH transition spectrum
- 7-segment pH display showing numerical value changing in real time
- \"Add Indicator\" button to add phenolphthalein
- 3D rotating molecule viewer showing HCl and NaOH structures

**Flame Test Lab:**
- Metal salt solution containers (sodium, copper, lithium, potassium, barium, strontium, calcium)
- Bunsen burner with flame
- Drag-and-drop interaction to place salt in flame
- Flame color changes: sodium yellow, copper green, lithium red, potassium lilac, barium pale green, strontium crimson, calcium orange-red
- Bloom glow animation effect
- Virtual spectrometer display showing wavelength peaks

**Electrochemical Voltaic Cell:**
- Zinc electrode in zinc sulfate solution
- Copper electrode in copper sulfate solution
- Salt bridge connecting two half-cells
- Animated electron flow through external wire
- Animated ion movement through salt bridge
- Live voltmeter displaying voltage reading

**Paper Chromatography:**
- Paper strip with plant pigment spot at bottom
- Solvent container
- \"Start\" button to begin solvent travel
- Animated solvent front moving up paper
- Pigment bands separating: chlorophylls, carotene, xanthophyll
- Live Rf value calculations displayed

**Exothermic vs Endothermic:**
- Virtual calorimeter container
- Reaction selection dropdown (exothermic/endothermic options)
- \"Start Reaction\" button
- Live temperature-vs-time graph
- Energy diagram showing enthalpy changes
- Temperature reading display

**Physics Experiment Simulations:**

**Simple Harmonic Motion (Pendulum):**
- Pendulum with adjustable length slider and mass selector
- \"Start Oscillation\" button
- Animated pendulum swinging with smooth motion
- Period and frequency calculations displayed
- Energy bar graphs showing kinetic/potential energy transformation
- Amplitude decay visualization

**Wave Interference & Superposition:**
- Two wave source points with adjustable frequency and amplitude sliders
- \"Start Waves\" button
- Animated circular wavefronts emanating from sources
- Interference pattern visualization with color gradient (constructive in bright, destructive in dark)
- Phase difference control slider
- Resultant wave amplitude display

**Projectile Motion Lab:**
- Cannon with launch angle slider (0-90 degrees) and initial velocity slider
- \"Launch\" button
- Animated projectile trajectory with velocity vector arrows
- Parabolic path traced in real-time
- Range, maximum height, and time of flight calculations displayed
- Grid background for distance reference

**Optics: Refraction & Snell's Law:**
- Light ray entering from air into glass/water medium
- Angle of incidence slider
- Refractive index selector for second medium
- Animated light ray bending at interface
- Normal line displayed
- Angle of refraction measured and displayed
- Snell's Law equation with live calculations (n1 sin θ1 = n2 sin θ2)

**Electric Fields & Potential:**
- Charge placement controls (positive/negative charges)
- Drag-and-drop charges onto canvas
- Animated electric field lines radiating from charges
- Equipotential surfaces shown as contour lines
- Electric potential visualization with color gradient (red for high, blue for low)
- Field strength indicator at cursor position

**Magnetic Force on Current:**
- Current-carrying wire displayed horizontally
- Current direction toggle button
- Magnetic field strength slider
- Magnetic field direction selector (into/out of page)
- Animated force arrow showing direction (Fleming's left-hand rule)
- Force magnitude calculation displayed (F = BIL)

**Thermodynamics: Carnot Cycle:**
- Four-stage cycle visualization with labeled stages
- P-V diagram showing cycle path
- Temperature sliders for hot and cold reservoirs
- \"Run Cycle\" button
- Animated piston movement through each stage
- Work done and heat transfer calculations
- Efficiency calculation displayed (η = 1 - Tc/Th)

**Quantum Tunneling Simulation:**
- Particle wave function approaching potential barrier
- Barrier width and height sliders
- Particle energy slider
- \"Send Particle\" button
- Animated wave function showing tunneling probability
- Transmission coefficient calculation displayed
- Probability density visualization with color gradient

**Gravitational Orbits (Kepler):**
- Central star with orbiting planet
- Planet mass and initial velocity sliders
- \"Start Orbit\" button
- Animated elliptical orbit with planet moving along path
- Orbital period calculation displayed
- Kepler's laws verification (equal areas in equal times visualization)
- Semi-major axis and eccentricity displayed

**Doppler Effect:**
- Moving sound source (car/ambulance) with velocity slider
- Stationary observer position marker
- \"Start Motion\" button
- Animated wavefronts showing compression ahead and expansion behind
- Observed frequency calculation displayed
- Original frequency vs observed frequency comparison
- Wavelength visualization

**Mathematics Experiment Simulations:**

**Limits & Continuity Visualizer:**
- Function input field (e.g., f(x) = (x^2-1)/(x-1))
- Function curve plotted on coordinate plane
- x-value slider approaching limit point
- Animated point tracing along curve
- Left limit and right limit values displayed
- Continuity check result shown

**Derivative Tracer (Tangent Line):**
- Function curve displayed on coordinate plane
- x-value slider
- Animated tangent line at selected point
- Slope calculation shown (rise/run)
- Derivative value f'(x) displayed
- Secant line animation approaching tangent

**Integral Area Visualizer:**
- Function curve with shaded area under curve
- Lower and upper bound sliders
- Number of rectangles slider (Riemann sum)
- Animated rectangles filling area
- Area calculation displayed
- Definite integral value shown

**Taylor Series Approximation:**
- Function input field (e.g., sin(x), e^x)
- Center point slider
- Number of terms slider (1-10)
- Original function curve in one color
- Animated polynomial approximation overlaying in another color
- Error visualization showing difference
- Coefficients displayed

**Matrix Transformation Visualizer:**
- 2x2 matrix input fields (a, b, c, d)
- Unit square displayed on coordinate plane
- \"Apply Transformation\" button
- Animated transformation showing rotation/scaling/shearing
- Transformed shape displayed
- Determinant and eigenvalues calculated and shown

**Complex Number Argand Plane:**
- Complex number input fields (real part a, imaginary part b)
- Point plotted on Argand plane (horizontal real axis, vertical imaginary axis)
- Modulus (distance from origin) displayed
- Argument (angle) displayed
- Operation selector (addition/multiplication with second complex number)
- Animated result showing geometric interpretation

**Fourier Series Builder:**
- Target waveform selector (square wave, sawtooth, triangle)
- Number of harmonics slider (1-20)
- Animated sine and cosine wave summation
- Resulting approximation curve overlaying target waveform
- Fourier coefficients displayed
- Error visualization

**Probability Distributions:**
- Distribution type selector (normal, binomial, Poisson)
- Parameter controls (mean, standard deviation, n, p, λ)
- Animated probability density/mass function curve
- Shaded area under curve for probability ranges
- Probability value displayed
- Cumulative distribution function option

**Vector Fields & Gradient:**
- Scalar field input (e.g., f(x,y) = x^2 + y^2)
- Animated vector field arrows showing gradient direction
- Contour lines for scalar values
- Magnitude color gradient (red for high, blue for low)
- Gradient vector at cursor position displayed

**Conic Sections Explorer:**
- Conic type selector (circle, ellipse, parabola, hyperbola)
- Parameter sliders (a, b, c for general equation)
- Animated curve drawing
- Equation displayed
- Focus points and directrix shown
- Eccentricity value displayed

**Computer Science Experiment Simulations:**

**Binary Search Visualizer:**
- Sorted array displayed as horizontal bar with indexed elements
- Search target input field
- \"Start Search\" button
- Animated binary search with left/right/mid pointers moving
- Current comparison highlighted in golden amber
- Comparison count displayed
- Time complexity O(log n) shown

**Sorting Algorithms:**
- Algorithm selector dropdown (bubble sort, merge sort, quick sort)
- Array input field (comma-separated numbers)
- \"Start Sort\" button
- Animated sorting process with color-coded comparisons (red) and swaps (green)
- Step-by-step visualization
- Comparison count and swap count displayed
- Time complexity comparison table

**Stack & Queue Operations:**
- Two side-by-side visualizations: Stack (vertical) and Queue (horizontal)
- Push/Pop buttons for Stack
- Enqueue/Dequeue buttons for Queue
- Animated element insertion and removal
- LIFO principle demonstration for Stack
- FIFO principle demonstration for Queue
- Current size displayed

**Binary Tree Traversal:**
- Interactive tree structure builder (click to add nodes)
- Traversal method selector (in-order, pre-order, post-order, level-order)
- \"Start Traversal\" button
- Animated node visiting sequence with color highlighting
- Visited order displayed as list
- Tree structure visualization with parent-child connections

**Graph Algorithms:**
- Interactive graph builder (click to add nodes, drag to connect edges)
- Algorithm selector (BFS, DFS, Dijkstra)
- Start node selector
- End node selector (for Dijkstra)
- \"Run Algorithm\" button
- Animated traversal with node coloring (visited=green, current=golden amber, unvisited=white)
- Shortest path highlighted for Dijkstra
- Step-by-step explanation

**Recursion Visualizer:**
- Recursive function selector (factorial, Fibonacci, Tower of Hanoi)
- Input parameter (n value)
- \"Start Recursion\" button
- Animated call stack visualization (stack frames growing and shrinking)
- Base case highlighted in green
- Recursive calls highlighted in golden amber
- Return values displayed

**Hash Table Operations:**
- Hash function visualization (key → hash value)
- Collision handling method selector (chaining, open addressing)
- Insert/Search/Delete operation buttons
- Key input field
- Animated hash calculation and bucket placement
- Collision resolution animation
- Load factor displayed

**Dynamic Programming:**
- Problem selector (0/1 knapsack, longest common subsequence)
- Input parameters (items/weights/values for knapsack, two strings for LCS)
- \"Solve\" button
- Animated memoization table filling
- Optimal substructure demonstration with color-coded cells
- Final solution highlighted
- Recurrence relation displayed

**Big O Notation:**
- Algorithm complexity selector (O(1), O(log n), O(n), O(n log n), O(n^2), O(2^n))
- Input size slider (1-100)
- Live graph plotting execution time vs input size for all complexities
- Color-coded curves for each complexity
- Comparison table showing relative performance

**Finite State Machine:**
- Interactive state diagram builder (click to add states, drag to add transitions)
- Input string field
- \"Process Input\" button
- Animated state transition based on input characters
- Current state highlighted in golden amber
- Accept state highlighted in green
- Reject state highlighted in red
- Transition labels displayed on edges

**Functionality:**
- All simulations are fully interactive using HTML5 Canvas or p5.js library
- All canvas text uses dark colors (deep forest green or black) on light backgrounds for readability
- Simulation state changes trigger AI interactions automatically
- \"Reset Experiment\" button resets simulation to initial state
- \"Finish Experiment\" button appears after minimum 5 AI interactions, navigates to Lab Report Screen
- Framer-motion fade-and-slide transition to Lab Report Screen

#### 3.4.2 Right Panel

**Layout:**
- Dr. Lab Widget at top (~200px height)
- Progress Indicators in middle
- \"Finish Experiment\" button at bottom

**Dr. Lab Widget (Top Section):**

**Purpose:** Display real-time AI explanations of scientific phenomena as student interacts with simulation

**Visual Elements:**
- Compact floating widget style (smart notification/explanation widget)
- Clean white background with subtle warm shadow and deep forest green left border
- Header: \"Dr. Lab\" title in Sora deep forest green, pulsing green dot indicator
- Explanation area: scrollable container showing last 2-3 explanations stacked vertically, newest on top
- Each explanation: circular robot avatar icon, timestamp, explanation text in Inter 14px warm sage green
- Loading state: \"Dr. Lab is analyzing...\" animation with three staggered bouncing deep forest green dots
- No input box, no chat history, no back-and-forth interaction

**Functionality:**
- useEffect fires on component mount to call <SKILL>large-language-model</SKILL> immediately for opening welcome message
- Debounced useEffect triggers on significant simulation events (valve opened, slider moved >10%, button clicked, phase change, reaction started)
- When student interacts with simulation, Dr. Lab automatically shows concise explanation of scientific phenomenon occurring
- Explanation limited to under 80 words
- Last 2-3 explanations displayed, older ones fade out
- All AI calls wrapped in try/catch blocks
- Every AI call shows \"Dr. Lab is analyzing...\" animation during loading
- On error, display retry option
- Auto-scroll to newest explanation

**Progress Indicators (Middle Section):**

**Visual Elements:**
- Five dot indicators filling deep forest green as interactions complete
- \"AI Interactions: X / 5 required\" counter in warm sage green
- Progress bar visualization

**Functionality:**
- Interaction count tracked and displayed
- Visual feedback as student progresses through experiment

**Finish Experiment Button (Bottom Section):**

**Visual Elements:**
- Large button in deep forest green with golden amber glow
- \"Finish Experiment & Generate Report\" text
- Appears only after 5 interactions completed

**Functionality:**
- Button hidden until minimum 5 AI interactions completed
- Clicking button navigates to Lab Report Screen
- Framer-motion fade-and-slide transition

### 3.5 Lab Report Screen

**Purpose:** Display personalized lab report generated by AI based on student session

**Visual Elements:**
- Background: warm cream #FAF8F3
- Four clean white cards with subtle warm shadows and deep forest green accent borders
- Experiment name and date at top in Sora deep forest green
- Large letter grade badge in Sora 64px with matching color (calculated based on number of AI questions answered)
- Four sections generated by <SKILL>large-language-model</SKILL>:
  - Objective
  - Observations
  - Analysis
  - Conclusion
- Animated background: slow-moving molecular structure particles in warm sage green
- Two buttons at bottom:
  - \"Download Report as PDF\" (deep forest green with golden amber hover, uses window.print() with clean print stylesheet)
  - \"Try Another Experiment\" (returns to Subject Selection Screen)

**Functionality:**
- Lab report content generated dynamically by calling <SKILL>large-language-model</SKILL> with summary of student session
- All AI calls wrapped in try/catch blocks
- Show loading animation during report generation
- On error, display retry option
- Grade calculated based on number of AI interactions completed
- \"Download Report as PDF\" triggers browser print dialog
- \"Try Another Experiment\" navigates back to Subject Selection Screen with Framer-motion fade-and-slide transition

### 3.6 3D Virtual Lab Screen

**Purpose:** Provide freeform chemistry lab environment where students can design their own experiments

**Visual Elements:**
- Background: realistic lab bench texture (wood grain or laminate surface)
- Equipment rack on left side with draggable items:
  - Glassware: beakers (50ml, 100ml, 250ml), Erlenmeyer flasks, test tubes, burettes, funnels, round-bottom flasks, graduated cylinders
  - Equipment: Bunsen burner, stand with clamps, thermometer, dropper, safety goggles icon, wash bottle, stirring rod, spatula
- Sink area in top-right corner for washing/emptying glassware
- Reagent shelf with labeled bottles:
  - Acids: HCl, H2SO4, HNO3, CH3COOH
  - Bases: NaOH, KOH, NH3
  - Salts: NaCl, AgNO3, Na2CO3, CuSO4, FeCl3, KMnO4, BaCl2, Pb(NO3)2
  - Indicators: universal indicator, phenolphthalein, methyl orange
  - Organic: ethanol, acetone, glucose
- All items cast realistic shadows for depth perception
- Glassware has glass transparency effects with liquid shimmer
- Flame animation on Bunsen burner when active

**Functionality:**
- All glassware and equipment use pointer events (pointerdown, pointermove, pointerup) for instant, smooth 60fps drag-and-drop with zero lag
- Dragged item follows cursor immediately with no delay, using requestAnimationFrame for smooth rendering
- Visual feedback: item highlights instantly on pointerdown, shadow increases during drag, returns to normal on pointerup
- Click reagent bottle to select, then click glassware to pour reagent into it
- Drag Bunsen burner under any vessel to heat it (visible flame animation appears)
- Drag thermometer into liquid to measure temperature
- Drag dropper to transfer small amounts between vessels
- Click wash bottle to rinse glassware
- Drag items to sink to empty/clean them
- Stand with clamps can hold glassware at adjustable heights
- When two reagents are mixed or heated, reaction matrix determines visual outcome

**Reaction Matrix (20+ Visual Outcomes):**

1. **AgNO3 + NaCl** → white AgCl precipitate forms, settles at bottom
2. **AgNO3 + HCl** → white AgCl precipitate forms
3. **Pb(NO3)2 + NaCl** → white PbCl2 precipitate forms
4. **BaCl2 + H2SO4** → white BaSO4 precipitate forms
5. **CuSO4 + NaOH** → blue Cu(OH)2 precipitate forms
6. **FeCl3 + NaOH** → brown Fe(OH)3 precipitate forms
7. **HCl + Na2CO3** → CO2 gas bubbles vigorously, fizzing animation
8. **H2SO4 + Na2CO3** → CO2 gas bubbles
9. **HNO3 + Na2CO3** → CO2 gas bubbles
10. **CH3COOH + Na2CO3** → CO2 gas bubbles (slower)
11. **Universal indicator + HCl** → solution turns red (pH 1-3)
12. **Universal indicator + NaOH** → solution turns purple (pH 12-14)
13. **Universal indicator + CH3COOH** → solution turns orange (pH 4-6)
14. **Phenolphthalein + NaOH** → solution turns pink
15. **Methyl orange + HCl** → solution turns red
16. **KMnO4 + H2SO4 + ethanol** → purple color fades (decolorization)
17. **Sodium salt + Bunsen burner** → yellow flame color
18. **Lithium salt + Bunsen burner** → red flame color
19. **Potassium salt + Bunsen burner** → lilac flame color
20. **Copper salt + Bunsen burner** → green flame color
21. **Barium salt + Bunsen burner** → pale green flame color
22. **Strontium salt + Bunsen burner** → crimson flame color
23. **Calcium salt + Bunsen burner** → orange-red flame color
24. **Heating CuSO4 solution** → water evaporates, blue crystals form
25. **Heating NaCl solution** → water evaporates, white crystals form

**AI Integration:**
- Dr. Lab widget appears on right side (same as Lab Bench Screen)
- When student performs action (mixes reagents, heats solution, adds indicator), Dr. Lab explains the chemistry
- Interaction count tracked, \"Finish Experiment\" button appears after 5 interactions

### 3.7 3D Rotating Molecule Viewer Component

**Purpose:** Display interactive 3D ball-and-stick molecular models

**Visual Elements:**
- Canvas-based 3D renderer using 2D canvas with rotation math (no external 3D library)
- Ball-and-stick model representation:
  - Atoms: colored spheres (carbon=black, hydrogen=white, oxygen=red, nitrogen=blue, chlorine=green, sodium=purple)
  - Bonds: cylinders connecting atoms (single/double/triple bonds)
- Continuously auto-rotates around Y-axis
- Click to pause/resume rotation
- Smooth 60fps animation

**Available Molecules:**
- Water (H2O): bent structure, 104.5° angle
- Carbon dioxide (CO2): linear structure
- Hydrogen chloride (HCl): diatomic molecule
- Sodium chloride (NaCl): ionic lattice unit cell
- Glucose (C6H12O6): ring structure
- DNA base pair (adenine-thymine): double helix segment
- Ethanol (C2H5OH): chain structure with OH group
- Benzene (C6H6): hexagonal ring with alternating double bonds
- Sodium hydroxide (NaOH): ionic structure

**Integration Points:**
- Appears in Acid-Base Titration canvas (showing HCl, NaOH, NaCl molecules)
- Appears in DNA Extraction Simulation canvas (showing DNA double helix)
- Appears in Organic Reactions Lab canvas (showing reactant and product molecules)
- Appears in Cellular Respiration canvas (showing glucose molecule)
- Appears in Photosynthesis Rate Lab canvas (showing CO2 and O2 molecules)
- Appears in Osmosis and Diffusion canvas (showing water molecule)
- Appears in Electrolysis of Water canvas (showing H2O, H2, O2 molecules)
- Appears in Le Chatelier's Principle canvas (showing NH3 molecule)
- Appears in Protein Synthesis Lab canvas (showing amino acid structure)

**Functionality:**
- Component receives molecule type as prop
- Renders appropriate 3D structure
- Auto-rotates continuously
- Click anywhere on canvas to toggle pause/resume
- Rotation speed: 1 degree per frame

### 3.8 Global Navigation Bar

**Appears on:** All screens after Landing/Home Screen

**Elements:**
- LabAI logo on left (deep forest green + golden amber)
- Progress indicator in center: Landing → Subject Selection → Experiment Selection → Lab Bench → Lab Report
- \"How It Works\" tooltip button on right in warm sage green
- Background: warm off-white with subtle bottom border
- No version tag or badge displayed

---

## 4. Business Rules and Logic

### 4.1 AI Integration

- All AI calls use built-in <SKILL>large-language-model</SKILL>
- Edge function accepts body with `system` field (string) and `messages` array (each with `role` and `content`)
- Edge function calls Gemini 2.5 Flash model via SSE streaming
- Parse AI response text from `candidates[0].content.parts[0].text` from SSE stream frames
- Every AI call must be wrapped in try/catch blocks
- Show \"Dr. Lab is analyzing...\" animation with three staggered bouncing deep forest green dots during every load
- Never show \"temporarily unavailable\" or blank states — always fallback gracefully with retry option
- System prompt for LLM: \"You are Dr. Lab, a friendly AI lab supervisor for high school and college students. When a student interacts with the simulation (moves a slider, adds a chemical, changes a variable), immediately explain the scientific phenomenon occurring in clear, accessible language tied directly to their action. This is a pure explanation widget — you do not ask questions or engage in conversation. Keep responses under 80 words. Be warm, encouraging, and educational.\"

### 4.2 AI Interaction Logic

- useEffect fires on Lab Bench Screen mount to send opening welcome message immediately
- Debounced useEffect triggers on significant simulation events:
  - **Biology experiments**: slider adjustments >10%, button clicks, phase transitions, process step completions
  - **Chemistry experiments**: valve opened, button clicks, slider adjustments >10%, reaction started, phase changes
  - **Physics experiments**: slider adjustments >10%, button clicks, simulation started, parameter changes
  - **Mathematics experiments**: slider adjustments >10%, button clicks, function input changes, transformation applied
  - **Computer Science experiments**: algorithm started, step executed, data structure modified, traversal step completed
  - **3D Virtual Lab**: reagent mixing, heating started, indicator added, precipitate formed, gas evolved
- When simulation state changes, trigger <SKILL>large-language-model</SKILL> with context about student action
- Dr. Lab immediately explains the scientific phenomenon occurring
- AI responses limited to under 80 words
- Last 2-3 explanations displayed in widget, newest on top

### 4.3 Experiment Completion Logic

- \"Finish Experiment\" button appears only after student has completed minimum 5 AI interactions
- Interaction count tracked in localStorage and displayed in progress indicators
- Five dot indicators fill deep forest green as interactions complete
- Upon clicking \"Finish Experiment\", session data sent to <SKILL>large-language-model</SKILL> to generate lab report

### 4.4 Grade Calculation

- Letter grade assigned based on number of AI interactions completed:
  - 5-7 interactions: C
  - 8-10 interactions: B
  - 11+ interactions: A
- Grade badge displays with matching color

### 4.5 Data Persistence

- User session data stored in localStorage:
  - Current subject selection
  - Current experiment progress
  - Explanation history (last 2-3 explanations)
  - Interaction count
  - Simulation state
  - 3D Virtual Lab state (item positions, reagent contents, reaction outcomes)
- Data persists across browser sessions
- No backend required

### 4.6 Responsive Behavior

- Desktop: Lab Bench Screen shows two-panel layout (60% simulation, 40% right panel)
- Mobile: Lab Bench Screen stacks panels vertically
- Subject Selection cards: responsive grid on desktop, stacked vertically on mobile
- Experiment Selection cards: scrollable vertical grid on all devices
- 3D Virtual Lab: equipment rack collapses to bottom toolbar on mobile

### 4.7 Design System

- Base color: warm off-white #FDFCF9
- Background color: warm cream #FAF8F3
- Primary color: deep forest green #1B4332
- Accent color: golden amber #F59E0B
- Secondary color: warm sage green #6B8E7F
- Card styling: clean white background, subtle warm shadows, deep forest green accent borders
- Fonts: Sora (headings), Inter (body) — imported from Google Fonts in HTML head
- Framer-motion fade-and-slide transitions between every screen
- 60fps requestAnimationFrame animations for simulation elements
- Premium science education SaaS feel with human-crafted design
- Warm typography, careful spacing, clean layout
- Canvas text: dark colors (deep forest green or black) on light backgrounds for readability
- Hero section animations use GPU-accelerated CSS transforms (translate3d, rotate3d) with will-change property for optimal performance

### 4.8 3D Virtual Lab Interaction Rules

- Items use pointer events (pointerdown, pointermove, pointerup) for instant, smooth 60fps drag-and-drop with zero lag
- Dragged item follows cursor immediately with no delay, using requestAnimationFrame for smooth rendering
- Visual feedback: item highlights instantly on pointerdown, shadow increases during drag, returns to normal on pointerup
- Glassware snaps to stand clamps when dragged near them
- Reagent pouring animation plays when reagent bottle is clicked then glassware is clicked
- Bunsen burner must be positioned under vessel to activate heating
- Heating effects: liquid shimmer increases, steam animation appears, temperature rises
- Reaction occurs immediately when two incompatible reagents are mixed
- Precipitate settles at bottom of vessel over 2 seconds
- Gas bubbles rise and pop at liquid surface
- Flame color changes are instant when salt is heated
- Thermometer shows temperature reading when immersed in liquid
- Wash bottle spray animation plays when clicked on glassware
- Sink drains liquid when glassware is dragged over it

### 4.9 3D Molecule Viewer Rendering

- Molecule data stored as atom coordinates and bond connections
- Rotation matrix applied to all atom coordinates each frame
- Atoms rendered as filled circles with radii based on atomic size
- Bonds rendered as lines connecting atom centers
- Z-sorting: atoms/bonds with higher Z-coordinate rendered last (painter's algorithm)
- Perspective projection: atoms farther away appear smaller
- Lighting: atoms on front face appear brighter than back face
- Rotation speed: 1 degree per frame around Y-axis
- Click detection: pause rotation when canvas is clicked, resume on next click

---

## 5. Exceptions and Edge Cases

| Scenario | Handling |
|----------|----------|
| LLM skill request fails | Display \"Dr. Lab is analyzing...\" animation, then show retry button with message \"Let's try that again\" |
| Student attempts to finish experiment before 5 interactions | \"Finish Experiment\" button remains hidden, progress indicators show current status |
| Student resets experiment mid-session | Clear simulation state, reset interaction count to 0, clear explanation history, AI sends new opening message via useEffect |
| localStorage is full or unavailable | Display warning: \"Unable to save progress. Please clear browser storage.\" Continue session without persistence |
| Student leaves page during experiment | Session data saved to localStorage, restored when returning |
| Canvas/p5.js fails to load | Display fallback message: \"Simulation unavailable. Please refresh the page.\" |
| AI response exceeds 80 words | Truncate response at 80 words |
| SSE stream parsing fails | Catch error, show retry option |
| Lab report generation fails | Show loading animation, then retry option on error |
| Canvas text has poor contrast | Ensure all text uses dark colors (deep forest green or black) on light backgrounds |
| More than 3 explanations in widget | Remove oldest explanation, keep only last 2-3 |
| Student drags item outside canvas bounds in 3D Virtual Lab | Item snaps back to last valid position |
| Student tries to mix incompatible reagents with no reaction defined | Dr. Lab explains \"No visible reaction occurs\" |
| Student tries to heat empty glassware | Dr. Lab warns \"Add reagents before heating\" |
| Student tries to pour reagent into full glassware | Display message \"Glassware is full\" |
| 3D molecule viewer fails to render | Display fallback 2D structural formula |
| Student clicks molecule viewer during auto-rotation | Rotation pauses, click again to resume |
| Pointer events not supported | Fallback to mouse events (mousedown, mousemove, mouseup) |
| Drag performance drops below 60fps | Reduce visual effects during drag, restore after pointerup |

---

## 6. Acceptance Criteria

1. User lands on Landing/Home Screen, sees optimized animated lab equipment illustrations with GPU-accelerated transforms, feature highlights (100+ experiments, AI tutor, virtual lab, quizzes), five subject cards with icons and hover effects, stats bar showing \"100 Experiments · 5 Subjects\", \"Start Learning\" CTA button, and \"Try 3D Virtual Lab\" button
2. User clicks \"Try 3D Virtual Lab\" button, navigates directly to 3D Virtual Lab Screen with Framer-motion fade-and-slide transition
3. User drags 100ml beaker from equipment rack using pointer events, beaker follows cursor instantly with zero lag at smooth 60fps, casts realistic shadow
4. User clicks AgNO3 reagent bottle, then clicks beaker, animated pouring occurs, beaker fills with clear solution
5. User clicks NaCl reagent bottle, then clicks same beaker, white AgCl precipitate forms immediately, settles at bottom over 2 seconds
6. User navigates back to Landing/Home Screen, clicks \"Start Learning\" button, navigates to Subject Selection Screen
7. User sees five compact subject cards: Biology (30 Experiments Available), Chemistry (30 Experiments Available), Physics (30 Experiments Available), Mathematics (30 Experiments Available), Computer Science (10 Experiments Available)
8. User clicks Computer Science card, navigates to Experiment Selection Screen showing ten CS experiments
9. User clicks \"Binary Search Visualizer\" experiment, navigates to Lab Bench Screen
10. User enters sorted array and search target, clicks \"Start Search\", sees animated binary search with left/right/mid pointers moving, comparison count incrementing
11. Dr. Lab widget shows \"Dr. Lab is analyzing...\" animation, then displays explanation of binary search algorithm, interaction counter increments to 1/5
12. User completes 5 AI interactions, \"Finish Experiment & Generate Report\" button appears
13. User clicks \"Finish Experiment\" button, navigates to Lab Report Screen showing four clean white cards with letter grade badge
14. User clicks \"Try Another Experiment\" button, navigates back to Subject Selection Screen
15. User observes global navigation bar on all screens after Landing/Home Screen, sees LabAI logo, progress indicator, \"How It Works\" button, no version tag or badge displayed
16. User navigates to Chemistry subject, clicks \"Acid-Base Titration\" experiment
17. User sees titration canvas with 3D rotating molecule viewer component showing HCl and NaOH structures auto-rotating
18. User clicks molecule viewer, rotation pauses, clicks again, rotation resumes
19. User adjusts burette tap, acid drips into beaker, liquid color changes through pH spectrum, 3D molecule viewer updates to show NaCl product
20. User completes experiment, downloads lab report as PDF via browser print dialog

---

## 7. Out of Scope for This Release

- User authentication or account system
- Backend server or database
- Additional experiments beyond the one hundred specified (30 Biology + 30 Chemistry + 30 Physics + 30 Mathematics + 10 Computer Science)
- Multiplayer or collaborative lab sessions
- Integration with external APIs or third-party services (other than built-in LLM skill)
- Advanced analytics or progress tracking across multiple sessions
- Customization of AI supervisor personality or teaching style
- Export lab reports in formats other than PDF
- Accessibility features beyond basic responsive design
- Internationalization or multi-language support
- Offline mode or PWA capabilities
- Admin dashboard or content management system
- File upload limits (type, size, quantity)
- Multi-device synchronization
- Social features (sharing, commenting, liking)
- Performance optimization beyond 60fps animations
- Browser compatibility testing beyond modern browsers
- Chat-based AI interaction (Dr. Lab is pure explainer widget, not conversational AI)
- Student input field or question submission to AI
- Chat history or conversation threading
- External 3D rendering libraries (Three.js, Babylon.js)
- VR/AR support for 3D Virtual Lab
- Real-time collaboration in 3D Virtual Lab
- Advanced physics simulation (fluid dynamics, thermodynamics beyond basic heating)
- Quantitative analysis tools (spectrophotometer, pH meter beyond visual indicator)
- Safety warnings or hazard information for reagents
- Lab notebook or experiment journal feature
- Video recording or screenshot capture of experiments
- Gamification elements (badges, leaderboards, achievements)
- Peer review or sharing of lab reports
- Integration with learning management systems (LMS)
- Custom experiment builder for educators
- Version tags or badges in header/navigation